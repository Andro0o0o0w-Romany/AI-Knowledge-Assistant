/**
 * Zustand Store - Global state management for auth
 */
import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";
import type { User } from "./api";

interface AuthState {
  // State
  token: string | null;
  user: User | null;
  isAuthenticated: boolean;
  hasHydrated: boolean;

  // Actions
  setAuth: (token: string, user: User) => void;
  setUser: (user: User) => void;
  logout: () => void;
  setHasHydrated: (state: boolean) => void;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      // Initial state
      token: null,
      user: null,
      isAuthenticated: false,
      hasHydrated: false,

      // Set authentication (after login/register)
      setAuth: (token: string, user: User) => {
        // Also store in localStorage for axios interceptor
        if (typeof window !== "undefined") {
          localStorage.setItem("token", token);
        }
        set({
          token,
          user,
          isAuthenticated: true,
        });
      },

      // Update user info
      setUser: (user: User) => {
        set({ user });
      },

      // Logout - clear all auth state
      logout: () => {
        if (typeof window !== "undefined") {
          localStorage.removeItem("token");
        }
        set({
          token: null,
          user: null,
          isAuthenticated: false,
        });
      },

      // Track hydration status (important for SSR)
      setHasHydrated: (state: boolean) => {
        set({ hasHydrated: state });
      },
    }),
    {
      name: "auth-storage",
      storage: createJSONStorage(() => localStorage),
      // Only persist these fields
      partialize: (state) => ({
        token: state.token,
        user: state.user,
        isAuthenticated: state.isAuthenticated,
      }),
      // Called after hydration
      onRehydrateStorage: () => (state) => {
        state?.setHasHydrated(true);
      },
    }
  )
);

