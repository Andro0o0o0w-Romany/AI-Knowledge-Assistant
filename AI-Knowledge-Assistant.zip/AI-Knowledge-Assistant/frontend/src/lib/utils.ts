/**
 * Utility functions for the frontend
 */
import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";
import { formatDistanceToNow, format, parseISO } from "date-fns";

/**
 * Combines class names with Tailwind CSS class merging
 * Uses clsx for conditional classes and tailwind-merge to resolve conflicts
 */
export function cn(...inputs: ClassValue[]): string {
  return twMerge(clsx(inputs));
}

/**
 * Normalize a date string to ensure it's treated as UTC
 * Backend returns UTC timestamps without 'Z' suffix, so we add it
 * to prevent parseISO from treating it as local time
 */
function normalizeToUTC(dateString: string): string {
  if (!dateString) return dateString;
  
  // If already has timezone indicator (Z, +, or - with offset), return as-is
  if (dateString.endsWith('Z') || /[+-]\d{2}:\d{2}$/.test(dateString)) {
    return dateString;
  }
  
  // Add 'Z' to indicate UTC
  return dateString + 'Z';
}

/**
 * Format a date string to relative time (e.g., "5 minutes ago")
 * Handles UTC timestamps from backend correctly
 */
export function formatRelativeTime(dateString: string): string {
  try {
    const utcDateString = normalizeToUTC(dateString);
    const date = parseISO(utcDateString);
    return formatDistanceToNow(date, { addSuffix: true });
  } catch {
    return "Unknown";
  }
}

/**
 * Format a date string to full date format (in user's local timezone)
 * Handles UTC timestamps from backend correctly
 */
export function formatDate(dateString: string): string {
  try {
    const utcDateString = normalizeToUTC(dateString);
    const date = parseISO(utcDateString);
    return format(date, "MMM d, yyyy 'at' h:mm a");
  } catch {
    return "Unknown";
  }
}

/**
 * Format bytes to human readable file size
 */
export function formatFileSize(bytes: number): string {
  if (bytes === 0) return "0 Bytes";

  const k = 1024;
  const sizes = ["Bytes", "KB", "MB", "GB"];
  const i = Math.floor(Math.log(bytes) / Math.log(k));

  return `${parseFloat((bytes / Math.pow(k, i)).toFixed(1))} ${sizes[i]}`;
}

/**
 * Truncate text to a maximum length with ellipsis
 */
export function truncateText(text: string, maxLength: number): string {
  if (text.length <= maxLength) return text;
  return text.slice(0, maxLength).trim() + "...";
}

/**
 * Get color class based on document status
 */
export function getStatusColor(status: string): string {
  switch (status) {
    case "completed":
      return "text-success";
    case "processing":
      return "text-info";
    case "pending":
      return "text-warning";
    case "failed":
      return "text-error";
    default:
      return "text-text-muted";
  }
}

/**
 * Get emoji icon for file type
 */
export function getFileIcon(fileType: string): string {
  switch (fileType.toLowerCase()) {
    case ".pdf":
      return "📄";
    case ".txt":
      return "📝";
    case ".doc":
    case ".docx":
      return "📃";
    case ".md":
      return "📋";
    default:
      return "📁";
  }
}

/**
 * Debounce function for search inputs
 */
export function debounce<T extends (...args: unknown[]) => unknown>(
  func: T,
  wait: number
): (...args: Parameters<T>) => void {
  let timeout: NodeJS.Timeout | null = null;

  return (...args: Parameters<T>) => {
    if (timeout) clearTimeout(timeout);
    timeout = setTimeout(() => func(...args), wait);
  };
}

/**
 * Generate a random ID
 */
export function generateId(): string {
  return Math.random().toString(36).substring(2, 9);
}

/**
 * Capitalize first letter of a string
 */
export function capitalize(str: string): string {
  return str.charAt(0).toUpperCase() + str.slice(1);
}

/**
 * Check if a string is a valid email
 */
export function isValidEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

/**
 * Sleep utility for async operations
 */
export function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

