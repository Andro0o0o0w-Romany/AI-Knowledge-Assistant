/**
 * API Client - Handles all HTTP requests to the backend
 */
import axios, { AxiosError } from "axios";

// Types
export interface User {
  id: number;
  email: string;
  username: string;
  is_active: boolean;
  is_superuser: boolean;
  created_at: string;
  updated_at: string;
}

export interface AuthResponse {
  access_token: string;
  token_type: string;
  user: User;
}

export interface Document {
  id: number;
  filename: string;
  original_filename: string;
  file_path: string;
  file_type: string;
  file_size: number;
  status: "pending" | "processing" | "completed" | "failed";
  chunk_count: number;
  embedding_count: number;
  content_preview: string | null;
  error_message: string | null;
  created_at: string;
  processed_at: string | null;
}

export interface DocumentListResponse {
  documents: Document[];
  total: number;
  total_chunks: number;
  total_embeddings: number;
}

export interface UploadResponse {
  message: string;
  documents: Document[];
  total_uploaded: number;
  successful: number;
  failed: number;
}

export interface SourceDocument {
  content: string;
  document_name: string;
  chunk_index: number;
  relevance_score: number;
}

export interface AskResponse {
  answer: string;
  sources: SourceDocument[];
  processing_time: number;
  question: string;
}

export interface ChatHistoryItem {
  id: number;
  question: string;
  answer: string;
  sources: SourceDocument[] | null;
  processing_time: number | null;
  created_at: string;
}

export interface ChatHistoryResponse {
  messages: ChatHistoryItem[];
  total: number;
}

export interface HealthResponse {
  status: string;
  app_name: string;
  version: string;
}

export interface DetailedHealthResponse {
  status: string;
  app_name: string;
  version: string;
  services: {
    database: {
      available: boolean;
    };
    vector_store: {
      available: boolean;
      total_embeddings: number;
    };
    llm: {
      llm_available: boolean;
      provider: string;
      model: string;
      embedding_model: string;
    };
  };
  config: {
    chunk_size: number;
    chunk_overlap: number;
    max_file_size_mb: number;
    allowed_extensions: string[];
  };
}

// Create axios instance
const api = axios.create({
  baseURL: "/api",
  headers: {
    "Content-Type": "application/json",
  },
});

// Request interceptor - add auth token
api.interceptors.request.use((config) => {
  if (typeof window !== "undefined") {
    const token = localStorage.getItem("token");
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
  }
  return config;
});

// Response interceptor - handle auth errors
api.interceptors.response.use(
  (response) => response,
  (error: AxiosError) => {
    if (error.response?.status === 401) {
      if (typeof window !== "undefined") {
        localStorage.removeItem("token");
        localStorage.removeItem("user");
        // Only redirect if not already on auth pages
        if (!window.location.pathname.includes("/login") && 
            !window.location.pathname.includes("/register")) {
          window.location.href = "/login";
        }
      }
    }
    return Promise.reject(error);
  }
);

// Auth API
export const authApi = {
  login: async (email: string, password: string): Promise<AuthResponse> => {
    const response = await api.post<AuthResponse>("/auth/login/json", {
      email,
      password,
    });
    return response.data;
  },

  register: async (
    email: string,
    username: string,
    password: string
  ): Promise<AuthResponse> => {
    const response = await api.post<AuthResponse>("/auth/register", {
      email,
      username,
      password,
    });
    return response.data;
  },

  me: async (): Promise<User> => {
    const response = await api.get<User>("/auth/me");
    return response.data;
  },

  logout: async (): Promise<void> => {
    await api.post("/auth/logout");
  },
};

// Documents API
export const documentsApi = {
  upload: async (files: File[]): Promise<UploadResponse> => {
    const formData = new FormData();
    files.forEach((file) => {
      formData.append("files", file);
    });

    const response = await api.post<UploadResponse>("/docs/upload", formData, {
      headers: {
        "Content-Type": "multipart/form-data",
      },
    });
    return response.data;
  },

  list: async (): Promise<DocumentListResponse> => {
    const response = await api.get<DocumentListResponse>("/docs");
    return response.data;
  },

  get: async (id: number): Promise<Document> => {
    const response = await api.get<Document>(`/docs/${id}`);
    return response.data;
  },

  delete: async (id: number): Promise<void> => {
    await api.delete(`/docs/${id}`);
  },

  reprocess: async (id: number): Promise<void> => {
    await api.post(`/docs/${id}/reprocess`);
  },
};

// Chat API
export const chatApi = {
  ask: async (question: string): Promise<AskResponse> => {
    const response = await api.post<AskResponse>("/ask", { question });
    return response.data;
  },

  getHistory: async (limit: number = 50): Promise<ChatHistoryResponse> => {
    const response = await api.get<ChatHistoryResponse>("/ask/history", {
      params: { limit },
    });
    return response.data;
  },

  clearHistory: async (): Promise<void> => {
    await api.delete("/ask/history");
  },

  deleteMessage: async (id: number): Promise<void> => {
    await api.delete(`/ask/history/${id}`);
  },
};

// Health API
export const healthApi = {
  check: async (): Promise<HealthResponse> => {
    const response = await api.get<HealthResponse>("/health");
    return response.data;
  },

  detailed: async (): Promise<DetailedHealthResponse> => {
    const response = await api.get<DetailedHealthResponse>("/health/detailed");
    return response.data;
  },
};

export default api;

