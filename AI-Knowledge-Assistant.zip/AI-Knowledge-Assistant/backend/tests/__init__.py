"""Test package for AI Knowledge Assistant."""

